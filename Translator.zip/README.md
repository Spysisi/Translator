# Пайтон - переводчик
## Пайтон - переводчик. Создан для того чтобы можно было в программе использовать выводы на экран в зависимости от того языка который выбрал пользователь
## Чтобы установить продукт вам нужно распаковать архив и открыть файл "Trans.py" в любом из пайтон компиляторе
## При открытии файла "Trans.py" в любом пайтон компиляторе (ОБЯЗАТЕЛЬНО: нужно чтобы файлы - словари были в 1 папке с файлом пайтона). После открытия вам предлогать выбрать язык на котором будут происходить дальнейшие действия. Так же для примера я создал 3 мини игры в которых используется моя разработка
/////////////////////////////////////////////////////////
# Python Translator
## Python is a translator. It was created so that the program could use the outputs on the screen, depending on the language that the user has chosen.
## To install the product, you need to unzip the archive and open the file. "Trans.py " in any of the python compilers
## When opening a file "Trans.py " in any python compiler (REQUIRED: dictionary files must be in 1 folder with the python file). After opening, you will be asked to choose the language in which further actions will take place. Also, for example, I created 3 mini-games that use my development.