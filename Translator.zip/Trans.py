from random import*
lg = "en"
i = 0
k = 1
bal = 100
while i == 0:
    lg = input("Choose your language: ru, en, fr  : ")
    if lg == "ru":
        with open("RU.txt", encoding='UTF-8') as f:
            lines = [line.rstrip('\n') for line in f]
        print(lines[0])
        i += 1
    elif lg == "en":
        with open("EN.txt", encoding='UTF-8') as f:
            lines = [line.rstrip('\n') for line in f]
        print(lines[0])
        i += 1
    elif lg == "fr":
        with open("FR.txt", encoding='UTF-8') as f:
            lines = [line.rstrip('\n') for line in f]
        print(lines[0])
        i += 1
    else:
        print("I couldn't recognize the text.")
while i == 1:
    print(lines[1], lines[5], lines[6], sep="\n")
    a = input("")
    if a == "lg":
        lg = input(lines[7])
        if lg == "ru":
            with open("RU.txt", encoding='UTF-8') as f:
                lines = [line.rstrip('\n') for line in f]
            print(lines[0])
        elif lg == "en":
            with open("EN.txt", encoding='UTF-8') as f:
                lines = [line.rstrip('\n') for line in f]
            print(lines[0])
        elif lg == "fr":
            with open("FR.txt", encoding='UTF-8') as f:
                lines = [line.rstrip('\n') for line in f]
            print(lines[0])
        else:
            print(lines[8])
    if a == "bal":
        print(lines[32])
    if a == "game":
        print(lines[2], lines[3], lines[4], sep="\n")
        a = input("")
        if a == "num":
            print(lines[10], lines[35])
            b = 0
            r = 0
            w = 0
            n = randint(0,1000)
            while w == 0:
                b = int(input(lines[11]))
                if b > int(n) and b != 9999:
                    print(lines[13])
                    r += 1
                elif b < int(n) and b != 9999:
                    print(lines[12])
                    r += 1
                elif b == n:
                    print(lines[14], r)
                    w += 1
                elif b == 9999:
                    w += 1
        if a == "RPS":
            print(lines[16], lines[21], sep="\n")
            b = 0
            while b == 0:
                n = randint(1,3) #1 - ножницы(S) 2 - камень(R) 3 бумага(P)
                p = input(lines[17])
                if n == 1: #ножницы
                    if p == "R":#выйгрыш
                        bal += 10
                        b += 1
                        print(lines[18], lines[32], bal)
                    if p == "S":
                        print(lines[20])#ничья
                    if p == "P":
                        b += 1
                        print(lines[19])#проигрыш
                if n == 2: #камень
                    if p == "R":
                        print(lines[20])
                        b += 1
                    if p == "S":
                        print(lines[19])
                    if p == "P":
                        b += 1
                        bal += 10
                        print(lines[18], lines[32], bal)#выйгрыш
                if n == 3: #бумага
                    if p == "R":
                        print(lines[19])
                        b += 1
                    if p == "S":
                        bal += 10
                        print(lines[18], lines[32], bal)#выйгрыш
                    if p == "P":
                        b += 1
                        print(lines[20])
                if p == "hub":
                    b += 1
        if a == "coin":
            print(lines[23], lines[21], sep="\n")
            b = 0
            while b == 0:
                su = int(input(lines[33]))
                if su <= bal:
                    summ = su
                    n = randint(1,2)
                    mon = input(lines[24])
                    if n == 1:
                        if mon == "eagle": #выйгрыш
                            summ = summ*2*k
                            bal = bal + summ
                            print(lines[25], lines[28], summ, lines[32], bal)
                        elif mon == "tails":
                            bal = bal - summ
                            k = 1
                            print(lines[26], lines[29], summ, lines[32], bal)
                    elif n == 2:
                        if mon == "tails": #выйгрыш
                            summ = summ*2*k
                            bal = bal + summ
                            print(lines[25], lines[28], summ, lines[32], bal)
                        elif mon == "eagle":
                            bal = bal - summ
                            k = 1
                            print(lines[26], lines[29], summ, lines[32], bal)
                if su > bal:
                    print(lines[34])
                if su == "hub":
                    b += 1
